

float readCO2()
{
    return 42.0;
}
float readTemp()
{
    return 1.0;
}
float readHumidity()
{
    return 2.0;
}
int doMeasurement()
{
    return 0; // no error
}
int DataReady()
{
    return 1; // data IS ready
}
