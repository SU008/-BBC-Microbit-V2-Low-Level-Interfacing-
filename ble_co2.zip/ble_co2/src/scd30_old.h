

float readCO2();
float readTemp();
float readHumidity();
int doMeasurement();
int DataReady();
