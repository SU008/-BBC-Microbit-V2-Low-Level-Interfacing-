#ifndef __BUTTONS_H
#define __BUTTONS_H
int get_buttonA();
int get_buttonB();
int buttons_begin();
#endif
